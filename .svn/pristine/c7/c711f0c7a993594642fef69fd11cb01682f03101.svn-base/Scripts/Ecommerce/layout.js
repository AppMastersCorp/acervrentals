﻿var layoutMenu;
$(function () {
    layoutMenu = new WebMenu().init('layout', '/Admin/Navigation/LayoutTree');
});
