﻿$(function () {
    $("form").validate();
});