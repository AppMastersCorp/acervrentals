﻿
$(function () {
    $("#parentVal").select2({
      
    });
});