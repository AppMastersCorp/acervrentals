﻿var webMenu;
$(function () {
    webMenu = new WebMenu().init('web', '/Admin/Navigation/WebSiteTree');
});
